#!/bin/bash
./date.sh &
