#!/bin/bash
while true
do
current=`date "+%Y-%m-%d %H:%M:%S"`  
timeStamp=`date -d "$current" +%s`

hwc=$(hwclock)
hwclock_arr=($hwc)
hwclock_time=${hwclock_arr[0]}" "${hwclock_arr[1]}" "${hwclock_arr[2]}" "${hwclock_arr[3]}" "${hwclock_arr[4]}" "${hwclock_arr[5]}" "${hwclock_arr[6]}
hwclock_timestamp=$(date -d "${hwclock_time}" +%s)

times=$(($hwclock_timestamp-$timeStamp))

k=100
if [ $times -gt $k ]
then
    hwclock --hctosys
	echo "time synchornized over"
fi
sleep 60
done

 
